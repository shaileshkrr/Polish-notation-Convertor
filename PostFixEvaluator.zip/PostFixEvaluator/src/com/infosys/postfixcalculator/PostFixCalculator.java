package com.infosys.postfixcalculator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.StringTokenizer;

public class PostFixCalculator {

	public static String evaluatePostFix(String inputPostfixExpr) {
		// Process the list into an ArrayList
		List<String> processedList = new ArrayList<String>();
		if (!inputPostfixExpr.isEmpty()) {
			StringTokenizer st = new StringTokenizer(inputPostfixExpr);
			while (st.hasMoreTokens()) {
				processedList.add(st.nextToken());
			}
		} else {
			return "Exception : Empty expression";
		}
		// A Stack, we will use this for the calculation
		Stack<String> tempList = new Stack<String>();
		// Iterate over the whole processed list
		Iterator<String> iter = processedList.iterator();
		while (iter.hasNext()) {
			String expressionChar = iter.next();
			if (expressionChar.matches("[0-9]*")) {

				// If the current item is a number (operand), push it onto the
				// stack
				tempList.push(expressionChar);
			} else if (expressionChar.matches("[*-/+]")) {

				try {
					evaluate(expressionChar, tempList);
				} catch (Exception e) {
					return "Exception : Invalid expression";

				}
			} else {
				return "Exception : incorrect expression format , add space in between every number and operator";
			}
		}
		if(tempList.size()==1){
			// Return the last element on the Stack
			return tempList.pop();
		}else{
			
			return "Exception : Invalid postfix expression";
		}
		
	}

	// If the current item is an operator we pop off the last
	// two elements
	// of our stack and calculate them using the operator we are
	// looking at.
	// Push the result onto the stack.
	static void evaluate(String operator, Stack<String> tempList) {
		int opr1 = Integer.parseInt(tempList.pop());
		int opr2 = Integer.parseInt(tempList.pop());
		int value = 0;
		switch (operator) {
		case "*":
			value = opr2 * opr1;
			break;
		case "/":
			value = opr2 / opr1;
			break;
		case "-":
			value = opr2 - opr1;
			break;
		case "+":
			value = opr2 + opr1;
			break;
		}
		tempList.push(Integer.toString(value));

	}

	public static void main(String args[]) {

		// input the postfix expression with spaces in between
		// eg: "65 3 5 * + 83 -"

		String result = PostFixCalculator.evaluatePostFix("65 3 5 * + 83 -");
		System.out.println(result);

	}

}
