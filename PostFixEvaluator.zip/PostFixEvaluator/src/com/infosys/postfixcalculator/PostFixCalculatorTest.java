package com.infosys.postfixcalculator;

import org.junit.Test;

import junit.framework.TestCase;

public class PostFixCalculatorTest extends TestCase {

	
	@Test
	public void testForEmptyExpression() {
		
		String message = PostFixCalculator.evaluatePostFix("");
		assertEquals(message, "Exception : Empty expression");
		
		
	}

	@Test
	public void testForInvalidExpr(){
		
		String message = PostFixCalculator.evaluatePostFix("3 + 4 * 9 - 5");
		assertEquals(message, "Exception : Invalid expression");
	}
	
	@Test
	public void testForFormat(){
		
		String message = PostFixCalculator.evaluatePostFix("3+2+44*-");
		assertEquals(message, "Exception : incorrect expression format , add space in between every number and operator");
	}
	
	@Test
	public void testForValidPostfixExpression(){
		
		String message = PostFixCalculator.evaluatePostFix("3 2 + 3 2 + 3 2 +");
		assertEquals(message, "Exception : Invalid postfix expression");
	}
}
